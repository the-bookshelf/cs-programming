public class UnderscoreTest {
    public static void main(String[] args) {
        int _ = 319;
        if ( _ > 300 ) {
            System.out.println("Your value us greater than 300.");
        }
        else {
            System.out.println("Your value is not greater than 300.");
        }
    }
}
