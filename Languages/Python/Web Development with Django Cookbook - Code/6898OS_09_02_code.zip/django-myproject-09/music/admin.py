# -*- coding: UTF-8 -*-
from django.contrib import admin

from models import Track

admin.site.register(Track)
