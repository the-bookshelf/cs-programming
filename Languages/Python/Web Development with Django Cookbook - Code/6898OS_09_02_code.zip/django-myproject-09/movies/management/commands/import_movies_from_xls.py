# -*- coding: UTF-8 -*-
import xlrd

from django.core.management.base import BaseCommand, CommandError
from django.utils.encoding import smart_str

from movies.models import Movie


SILENT, NORMAL, VERBOSE, VERY_VERBOSE = 0, 1, 2, 3


class Command(BaseCommand):
    args = "<file_path>"
    help = "Imports movies from a local XLS file. Expects title, URL, and release year."

    def handle(self, *args, **options):
        verbosity = int(options.get("verbosity", NORMAL))
        if args:
            file_path = args[0]
        else:
            raise CommandError("Pass a path to a XLS file")

        wb = xlrd.open_workbook(file_path)
        sh = wb.sheet_by_index(0)

        if verbosity >= NORMAL:
            print "=== Movies imported ==="
        for rownum in xrange(sh.nrows):
            if rownum > 0:  # let"s skip the column captions
                (title, url, release_year) = sh.row_values(rownum)
                movie, created = Movie.objects.get_or_create(
                    title=title,
                    url=url,
                    release_year=release_year,
                )
                if verbosity >= NORMAL:
                    print " - " + smart_str(movie.title)
