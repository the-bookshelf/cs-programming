# -*- coding: UTF-8 -*-
import xlwt

from django.db import models
from django.contrib import admin
from django.utils.translation import ugettext_lazy as _
from django.http import HttpResponse

from products.models import Product, ProductPhoto


class ProductPhotoInline(admin.StackedInline):
    model = ProductPhoto
    extra = 0


def export_xls(modeladmin, request, queryset):
    response = HttpResponse(mimetype='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=products.xls'
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet("Products")

    row_num = 0

    columns = [
        (u"ID", 2000),
        (u"Title", 6000),
        (u"Description", 8000),
        (u"Price (€)", 3000),
    ]

    header_style = xlwt.XFStyle()
    header_style.font.bold = True

    for col_num in xrange(len(columns)):
        ws.write(row_num, col_num, columns[col_num][0], header_style)
        # set column width
        ws.col(col_num).width = columns[col_num][1]

    text_style = xlwt.XFStyle()
    text_style.alignment.wrap = 1

    price_style = xlwt.XFStyle()
    price_style.num_format_str = '0.00'

    styles = [text_style, text_style, text_style, price_style]

    for obj in queryset.order_by('pk'):
        row_num += 1
        row = [
            obj.pk,
            obj.title,
            obj.description,
            obj.price,
        ]
        for col_num in xrange(len(row)):
            ws.write(row_num, col_num, row[col_num], styles[col_num])

    wb.save(response)
    return response

export_xls.short_description = u"Export XLS"


class PhotoFilter(admin.SimpleListFilter):
    # Human-readable title which will be displayed in the
    # right admin sidebar just above the filter options.
    title = _('photos')

    # Parameter for the filter that will be used in the URL query.
    parameter_name = 'photos'

    def lookups(self, request, model_admin):
        """
        Returns a list of tuples. The first element in each
        tuple is the coded value for the option that will
        appear in the URL query. The second element is the
        human-readable name for the option that will appear
        in the right sidebar.
        """
        return (
            ('0', _('Has no photos')),
            ('1', _('Has one photo')),
            ('2+', _('Has more than one photo')),
        )

    def queryset(self, request, queryset):
        """
        Returns the filtered queryset based on the value
        provided in the query string and retrievable via
        `self.value()`.
        """
        if self.value() == '0':
            return queryset.annotate(
                num_photos=models.Count('productphoto')
            ).filter(num_photos=0)
        if self.value() == '1':
            return queryset.annotate(
                num_photos=models.Count('productphoto')
            ).filter(num_photos=1)
        if self.value() == '2+':
            return queryset.annotate(
                num_photos=models.Count('productphoto')
            ).filter(num_photos__gte=2)


class ProductAdmin(admin.ModelAdmin):
    list_display = ['title', 'get_photo', 'price']
    list_editable = ['price']
    list_filter = [PhotoFilter]

    fieldsets = (
        (_('Product'), {'fields': ('title', 'slug', 'description', 'price')}),
    )

    prepopulated_fields = {'slug': ('title',)}
    inlines = [ProductPhotoInline]
    actions = [export_xls]

    def get_photo(self, obj):
        project_photos = obj.productphoto_set.all()[:1]
        if project_photos:
            return u"""<a href="%(product_url)s" target="_blank">
                <img src="%(photo_url)s" alt="" width="100" />
            </a>""" % {
                'product_url': obj.get_url_path(),
                'photo_url':  project_photos[0].photo.url,
            }
        return u""
    get_photo.short_description = _('First photo')
    get_photo.allow_tags = True


admin.site.register(Product, ProductAdmin)
