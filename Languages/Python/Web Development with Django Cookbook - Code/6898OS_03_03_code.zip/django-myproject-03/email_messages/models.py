# -*- coding: UTF-8 -*-

from django.db import models
