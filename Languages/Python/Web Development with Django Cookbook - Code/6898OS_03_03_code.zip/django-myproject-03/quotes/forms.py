# -*- coding: UTF-8 -*-
from django import forms

from models import InspirationQuote


class InspirationQuoteForm(forms.ModelForm):
    class Meta:
        model = InspirationQuote
