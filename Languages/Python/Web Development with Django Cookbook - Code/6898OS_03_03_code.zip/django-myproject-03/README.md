This is an example project for the chapter "Forms and Views" of the book "Django Web Development Cookbook" by Aidas Bendoraitis.

To install requirements run:
pip install -r requirements.txt

To login to administration, use username "admin" and password "admin".

To see recipes in action, run the development server:
$ python manage.py runserver

To test the recipes "Passing HttpRequest to the form" and "The save method of the form" go to
http://127.0.0.1:8000/email-messages/

To test the recipe "Uploading images" go to
http://127.0.0.1:8000/quotes/add/

To test the recipe "Creating form layout with django-crispy-forms" go to
http://127.0.0.1:8000/bulletin-board/

To test the recipes "Filterable lists" and "Pagination" go to
http://127.0.0.1:8000/movies/

To test the recipe "Class-based views" go to
http://127.0.0.1:8000/movies/alternative/

To test the recipe "Generating PDF documents" go to
http://127.0.0.1:8000/cv/1/pdf/
