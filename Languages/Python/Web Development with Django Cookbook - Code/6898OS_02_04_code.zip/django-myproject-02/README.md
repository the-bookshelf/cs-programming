This is an example project for the chapter "Database Structure" of the book "Django Web Development Cookbook" by Aidas Bendoraitis.

To login to administration run local server, go to
http://127.0.0.1:8000/en/admin/
and enter username "admin" and password "admin"