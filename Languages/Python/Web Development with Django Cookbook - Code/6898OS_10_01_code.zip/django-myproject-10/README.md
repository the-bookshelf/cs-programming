This is an example project for the chapter "Bells and Whistles" of the book "Django Web Development Cookbook" by Aidas Bendoraitis.

To install requirements run:
pip install -r requirements.txt

To start, run the development server:
$ python manage.py runserver

To login to administration, use username "admin" and password "admin".

To test the recipes "Monkey patching slugification functions" and "Monkey patching model administration"
check the app guerrilla_patches and open:
http://127.0.0.1:8000/admin/books/book/

To test the recipe "Toggling debug toolbar", open any page, e.g.
http://127.0.0.1:8000/admin/books/book/

To see the recipe "Using ThreadLocalMiddleware" in action, save a chosen book in administration:
http://127.0.0.1:8000/admin/books/book/
Current user will be saved as the creator of the book.

To read the code for the recipe "Detailed error reporting by email", open settings.py

To read the code for the recipe "Deploying on Apache with mod_wsgi",
check the directory "public_html"

To read the Fabric script for the recipe "Creating and using Fabric deployment script",
check fabfile.py